# Cosmic Pizzas🌌

A pizza 🍕 customization and delivery 🚚 service built in pure HTML, CSS & 🍦JS.

### Useless stuff:
- 8 veg 🍅 and 5 non-veg 🍗 toppings to choose from.
- 5 crusts to choose from.
- Real time data of how your pizza would look 👀.
- GST at only 5%.
- Can order upto 5 pizzas at the same time.
- Absolutely NO discount!

![screenshot](/assets/images/screenshot.png)
